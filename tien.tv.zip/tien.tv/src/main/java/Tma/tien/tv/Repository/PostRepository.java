package Tma.tien.tv.Repository;

import Tma.tien.tv.Entity.Post;
import org.springframework.data.repository.CrudRepository;

public interface PostRepository extends CrudRepository<Post, Integer> {
}
