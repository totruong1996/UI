package Tma.tien.tv.Controller;

import Tma.tien.tv.Entity.Post;
import Tma.tien.tv.Entity.User;
import Tma.tien.tv.Repository.PostRepository;
import Tma.tien.tv.Repository.UserRepository;
import Tma.tien.tv.Service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping(path = "/demo")
public class MainController {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PostRepository postRepository;

    @Autowired
    private PostService postService;

    @PostMapping(path = "/add")
    public @ResponseBody
    String AddNewUser(@Valid @RequestBody User u) {
        User user = new User();
        user.setName(u.getName());
        user.setEmail(u.getEmail());
        userRepository.save(user);
        return "Saved";
    }


    @GetMapping(path = "/alluser")
    public @ResponseBody
    Iterable<User> getAllUsers() {
        // This returns a JSON or XML with the users
        return userRepository.findAll();
    }

    @GetMapping(path = "/id")
    public @ResponseBody
    User getByName(@RequestParam Integer id) {

        return userRepository.findById(id).orElseGet(() -> new User());
    }


    @PutMapping(path = "/update/{id}")
    public @ResponseBody
    String update(@PathVariable(value = "id") Integer id, @Valid @RequestBody User u) {
        User user = userRepository.findById(id).orElseGet(() -> new User());
        user.setEmail(u.getEmail());
        user.setName(u.getName());
        userRepository.save(user);
        return "updated";
    }

    @DeleteMapping(path = "/delete/{id}")
    public @ResponseBody
    String delete(@PathVariable(value = "id") Integer id) {
        User user = userRepository.findById(id).orElseGet(() -> new User());
        userRepository.delete(user);
        return "deleted";
    }

    @DeleteMapping(path = "/dname")
    public @ResponseBody
    String deleteByName(@RequestParam Integer id) {
        userRepository.deleteIdQuery(id);
        return "deleted";
    }

    @GetMapping(path = "/nameList")
    public @ResponseBody
    List<User> findByName(@RequestParam String name) {
        List<User> users = userRepository.findByNameQuery(name);
        return users;
    }

    @PostMapping(path = "/insert")
    public @ResponseBody
    String insertQuery(@RequestBody User u) {
        userRepository.insertQuery(u.getName(), u.getEmail());
        return "inserted";
    }

    @GetMapping(path = "/welcome")
    public String welcome() {
        return "welcome";
    }

    @PostMapping(path = "/SavePost")
    public String Save(@Valid @ModelAttribute("postForm") Post post, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "Insert";
        }
        postRepository.save(post);
        model.addAttribute("p", post);
        return "welcome";

    }

    @GetMapping(path = "/SavePost")
    public String SaveView(Model model) {
        Post post = new Post();
        model.addAttribute("postForm", post);
        return "Insert";
    }

    @GetMapping(path = "/listPost")
    public String ListPost(ModelMap modelMap) {

        Iterable<Post> list = postRepository.findAll();
        modelMap.put("list", list);
        return "ListPost";
    }

    @GetMapping (path = "/deletePost/{id}")
    public
    String DeletePost(@PathVariable(name = "id") int id) {
        postService.Delete(id);
        return "welcome";

    }

    //show page update
    @GetMapping(path = "/updatePost/{id}")
    public String update(@PathVariable(name = "id")int id, ModelMap modelMap){

        Post post = postRepository.findById(id).orElseGet(() -> new Post());
        if(post==null){
            return "welcome";
        }
        modelMap.addAttribute("postForm", post);

        return "Update";

    }
    @GetMapping(path = "/contactus")
    public String ContactUs(){
        return "contactusPage";
    }

    @GetMapping(path = "/homepage")
    public String HomePage(){
        return "homePage";
    }
}
