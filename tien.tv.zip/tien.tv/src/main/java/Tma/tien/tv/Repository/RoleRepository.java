package Tma.tien.tv.Repository;

import Tma.tien.tv.Entity.Role;
import org.springframework.data.repository.CrudRepository;

public interface RoleRepository extends CrudRepository<Role, Integer> {

    public Role findByRole(String role);
}
