export const SORT = 'SORT';
export const TOGGLE = 'TOGGLE_STATUS';