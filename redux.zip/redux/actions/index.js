
export const toggle  = ()=>{
	return  {
		type : 'TOGGLE_STATUS'
	}
}
export const Sort = (sort)=>{
	return {
		type:'SORT',
		sort
	}
}