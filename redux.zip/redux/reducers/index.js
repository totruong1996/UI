import {combineReducers} from 'redux';
 import sort from  './reducerSort';
 import status from  './reducerToggle';

 const reducer = combineReducers({
 	sort, status
 });
 export default reducer;