import * as types from './../constants';
var initState = {
	by:'status',
	value : -1
};

var reducer = (state =  initState, action)=>{
	if(action.type===types.SORT){
		var {by,value} =  action.sort;

		return {
			by,value
		};
	}
	return state;
}
export default reducer;