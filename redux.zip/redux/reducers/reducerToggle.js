import * as types from './../constants';
var initState = false;

var reducer = (state =  initState, action)=>{
	if(action.type===types.TOGGLE){
		state = !state; 
		return state;
	}
	return state;
}
export default reducer;