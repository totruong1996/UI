import {createStore} from 'redux';
import * as types from './constants';
import {Sort, toggle} from './actions/index';
import reducer from './reducers/index';


//toggle status


const store = createStore(reducer);
console.log('DEFAULT',store.getState());
store.dispatch(toggle());
console.log('toggle', store.getState());
store.dispatch(Sort({
	by: 'status',
	value : -1
}));
console.log('sort', store.getState());